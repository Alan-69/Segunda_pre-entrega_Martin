
from modulo1 import Cliente
from modulo1 import Compra


cliente1 = Cliente("Alan","Martin", 30, "alan123@gmail")
compra1 = Compra("Computadora", "PC Center")

cliente2 = Cliente("Rodri", "nose", 40, "rodri@gmail")
compra2 = Compra("Auriculares", "Walmart")

