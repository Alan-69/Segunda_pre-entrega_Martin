#Creamos una clase con el nombre "Cliente"
class Cliente():
    
    #Atributos de clase
    cantidad =0
    
    #Constructor
    def __init__(self, nombre, apellido, edad, correo):
        
        #Atributos de instancia
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self.correo = correo
        
        Cliente.cantidad += 1
        
    #Métodos
    def __str__(self):
        return (f"\nSe ha creado al cliente: " +self.nombre+" "+self.apellido+"")
    
    def mail(self):
        print (f"Se ha enviado la factura de la compra al correo: {self.correo}")
    
    #Creo otra clase para agregar atributos especiales al cliente
class Compra():
        def __init__(self, item, tienda):
            self.item = item
            self.tienda = tienda
            
        def __str__(self):
            return (f"Compra realizada: {self.item}\nTienda: {self.tienda}\n")


cliente1 = Cliente("Alan","Martin", 30, "alan123@gmail")
compra1 = Compra("Computadora", "PC Center")

cliente2 = Cliente("Rodri", "nose", 40, "rodri@gmail")
compra2 = Compra("Auriculares", "Walmart")

print(f"Total de clientes registrados: {Cliente.cantidad}")

