from setuptools import setup

setup(
    name="mi_paquete",
    version="1.0",
    description="Clientes",
    author="Alan Martin",
    author_email="alanpablo69@gmail.com",
    packages=["mi_paquete"]
)